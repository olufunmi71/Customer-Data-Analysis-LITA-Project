Create Database COSTUMERDATAANALYSIS_DB

CREATE TABLE [dbo].[CustomerData] (
    CustomerID INT PRIMARY KEY,
    CustomerName NVARCHAR(100),
    Region NVARCHAR(50),
    SubscriptionType NVARCHAR(50),
    SubscriptionStart DATE,
    SubscriptionEnd DATE,
    Canceled NVARCHAR(10),
    Revenue DECIMAL(10, 2),
    SubscriptionDuration INT 
);


;WITH CTE AS (
SELECT 
      *, 
 ROW_NUMBER() OVER (PARTITION BY CustomerID, CustomerName, Region, SubscriptionType, SubscriptionStart, SubscriptionEnd, Canceled, Revenue, SubscriptionDuration ORDER BY CustomerID) AS RowNum
 FROM 
[dbo].[LITA Capstone CUSTOMERDATA]
)
DELETE FROM CTE
WHERE RowNum > 1;


SELECT 
CustomerID, CustomerName, Region, SubscriptionType, SubscriptionStart, SubscriptionEnd, Canceled, Revenue, SubscriptionDuration,
 COUNT(*) AS DuplicateCount
FROM 
    [dbo].[LITA Capstone CUSTOMERDATA]
GROUP BY 
 CustomerID, CustomerName, Region, SubscriptionType, SubscriptionStart, SubscriptionEnd, Canceled, Revenue, SubscriptionDuration
HAVING 
COUNT(*) > 1;


WITH CustomerCountByRegion AS (
SELECT 
Region, 
COUNT(DISTINCT CustomerID) AS TotalCustomers
FROM 
[dbo].[LITA Capstone CUSTOMERDATA]
GROUP BY 
Region
)
SELECT * FROM CustomerCountByRegion
ORDER BY TotalCustomers DESC;


WITH PopularSubscriptionType AS (
 SELECT 
SubscriptionType, 
COUNT(DISTINCT CustomerID) AS CustomerCount
FROM 
[dbo].[LITA Capstone CUSTOMERDATA]
GROUP BY 
SubscriptionType
)
SELECT TOP 1 * FROM PopularSubscriptionType
ORDER BY CustomerCount DESC;

WITH EarlyCancellations AS (
    SELECT 
        CustomerID, 
        CustomerName, 
        SubscriptionType, 
        DATEDIFF(MONTH, SubscriptionStart, SubscriptionEnd) AS DurationMonths
    FROM 
        [dbo].[LITA Capstone CUSTOMERDATA]
    WHERE 
        Canceled = 1 
        AND DATEDIFF(MONTH, SubscriptionStart, SubscriptionEnd) <= 6
)
SELECT * FROM EarlyCancellations
ORDER BY DurationMonths ASC;


WITH AvgSubscriptionDuration AS (
SELECT 
AVG(SubscriptionDuration) AS AverageDurationMonths
FROM 
[dbo].[LITA Capstone CUSTOMERDATA]
)
SELECT * FROM AvgSubscriptionDuration;


WITH LongSubscriptions AS (
SELECT 
        CustomerID, 
        CustomerName, 
        SubscriptionType, 
        SubscriptionDuration
    FROM 
        [dbo].[LITA Capstone CUSTOMERDATA]
    WHERE 
        SubscriptionDuration = 12
)
SELECT * FROM LongSubscriptions
ORDER BY CustomerName;

WITH RevenueBySubscriptionType AS (
SELECT 
SubscriptionType, 
SUM(Revenue) AS TotalRevenue
 FROM 
[dbo].[LITA Capstone CUSTOMERDATA]
GROUP BY 
 SubscriptionType
)
SELECT * FROM RevenueBySubscriptionType
ORDER BY TotalRevenue DESC;


WITH TopCancelledRegions AS (
    SELECT 
        Region, 
COUNT(CustomerID) AS CancellationCount
    FROM 
        [dbo].[LITA Capstone CUSTOMERDATA]
    WHERE 
        Canceled = 1
    GROUP BY 
        Region
)
SELECT TOP 3 * FROM TopCancelledRegions
ORDER BY CancellationCount DESC;


WITH SubscriptionStatus AS (
    SELECT 
        CASE 
            WHEN Canceled = 1 THEN 'Canceled'
            ELSE 'Active'
        END AS SubscriptionStatus,
        COUNT(CustomerID) AS TotalSubscriptions
    FROM 
        [dbo].[LITA Capstone CUSTOMERDATA]
    GROUP BY 
        CASE 
            WHEN Canceled = 1 THEN 'Canceled'
            ELSE 'Active'
        END
)
SELECT * FROM SubscriptionStatus;